﻿using System;
using System.Collections.Generic;

namespace FizzLib
{
    public struct FizzBuzzResult
    {
        public string Result;
    }

    public struct Evaluator
    {
        public int DivisibleBy;
        public string Display;

        public Evaluator(int divBy, string disp)
        {
            DivisibleBy = divBy;
            Display = disp;
        }
    }

    public class FizzBuzz
    {
        private Evaluator _eval1;
        private Evaluator _eval2;

        public FizzBuzz(Evaluator eval1, Evaluator eval2)
        {
            _eval1 = eval1;
            _eval2 = eval2;
        }

        public IEnumerable<FizzBuzzResult> GetFizzBuzz(int minVal = 1, int maxVal = 100)
        {
            List<FizzBuzzResult> rtnVal = new List<FizzBuzzResult>();
            FizzBuzzResult currEval;
            string result = string.Empty;
            bool match1 = false;
            bool match2 = false;

            for (var i = minVal; i <= maxVal; i++)
            {
                currEval = new FizzBuzzResult();
                result = i.ToString();
                match1 = i % _eval1.DivisibleBy == 0;
                match2 = i % _eval2.DivisibleBy == 0;

                if (match1)
                {
                    result = _eval1.Display;
                }

                if (match2)
                {
                    result = _eval2.Display;
                }

                if (match1 && match2)
                {
                    result = _eval1.Display + _eval2.Display;
                }

                currEval.Result = result;

                rtnVal.Add(currEval);
            }

            return rtnVal;
        }
    }
}