﻿using System;
using System.Collections.Generic;
using FizzLib;

namespace FizzClient
{
    class Program
    {
        static void Main(string[] args)
        {
            FizzBuzz fb = new FizzBuzz(new Evaluator(3, "Fizz"), new Evaluator(5, "Buzz"));
            IEnumerable<FizzBuzzResult> res = fb.GetFizzBuzz();

            Console.WriteLine("Range 1 - 100: ");
            Console.WriteLine(string.Empty);

            PrintPositiveResults(fb, 1, 100);

            Console.WriteLine("Range 1 - int.Max: ");
            Console.WriteLine(string.Empty);

            PrintPositiveResults(fb, 1, int.MaxValue);

            Console.WriteLine("Range int.Min - int.Max: ");
            Console.WriteLine(string.Empty);

            PrintNegativeResults(fb);
            PrintPositiveResults(fb, 1, int.MaxValue);

            Console.ReadKey();
        }

        private static void PrintPositiveResults(FizzBuzz fb, int minNum, int maxNum)
        {
            IEnumerable<FizzBuzzResult> res;
            var a = 10000000;
            int loops = maxNum / a;
            var loopRem = maxNum % a;
            var minVal = minNum;

            for (var ctr = 1; ctr <= loops; ctr++)
            {
                res = fb.GetFizzBuzz(minVal, ctr * a);

                foreach (var o in res)
                {
                    Console.WriteLine(o.Result);
                }

                minVal = (ctr * a) + 1;
            }

            res = fb.GetFizzBuzz(minVal, (loops * a) + loopRem);

            foreach (var o in res)
            {
                Console.WriteLine(o.Result);
            }
        }

        private static void PrintNegativeResults(FizzBuzz fb)
        {
            IEnumerable<FizzBuzzResult> res;
            var a = 10000000;
            int loops = Int32.MaxValue / a;
            var loopRem = Int32.MaxValue % a;
            var minVal = Int32.MinValue;
            var maxVal = 0;

            for (var ctr = 1; ctr <= loops; ctr++)
            {
                maxVal = minVal + (ctr * a);
                res = fb.GetFizzBuzz(minVal, maxVal);

                foreach (var o in res)
                {
                    Console.WriteLine(o.Result);
                }

                minVal = maxVal + 1;
            }

            res = fb.GetFizzBuzz(minVal, 0);

            foreach (var o in res)
            {
                Console.WriteLine(o.Result);
            }
        }
    }
}
